from django.contrib import admin
from django.contrib.auth.models import User
from .models import Deceased
# Optionally, you can customize the User model admin
class UserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff', 'is_active')
    search_fields = ('username', 'email')

# Unregister the default User model (if it's already registered) to prevent conflicts
admin.site.unregister(User)
admin.site.register(User, UserAdmin)

# You can also register other models here as needed:
from .models import Member, ContactInquiry, Service, ServiceRequest

# Registering other models (if applicable)
admin.site.register(Member)
admin.site.register(ContactInquiry)
admin.site.register(Service)
admin.site.register(ServiceRequest)

@admin.register(Deceased)
class DeceasedAdmin(admin.ModelAdmin):
    list_display = ('name', 'unique_id', 'burial_section', 'date_of_death', 'date_of_burial')  # Fields shown in admin list
    search_fields = ('name', 'unique_id', 'burial_section')  # Enable search for these fields
    list_filter = ('burial_section', 'date_of_burial')  # Filter by burial section and burial date