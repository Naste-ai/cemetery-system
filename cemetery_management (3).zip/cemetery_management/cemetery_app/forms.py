from django import forms
from .models import Member, ContactInquiry
from .models import ServiceRequest
class LoginForm(forms.ModelForm):
    name = forms.CharField(max_length=255) 
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = Member
        fields = ['name', 'password']
class ServiceRequestForm(forms.ModelForm):
    class Meta:
        model = ServiceRequest
        fields = ['service', 'email', 'total_price']