from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib import messages
from .models import Member
from django.contrib.auth import authenticate, login
from .forms import LoginForm
from .models import Member, Service  

# Home view
def home(request):
    return render(request, 'cemetery_app/home.html')

# Services view
def services(request):
    services = Service.objects.all()  # Get all services
    return render(request, 'cemetery_app/services.html', {'services': services})

# Pay Now view
def paynow(request):
    if request.method == 'POST':
        # Get form data
        service = request.POST.get('service')
        maintenance_type = request.POST.get('maintenance_type')
        spot_type = request.POST.get('spot_type')
        name = request.POST.get('name')
        email = request.POST.get('email')

        # Define service prices
        service_prices = {
            'cleaning': 2000,
            'digging': 3000,
            'both': 4500,
            'schedule_anniversary': 10000,
            'family': 15000,
            'kids': 8000,
            'general': 10000,
        }

        # Calculate total price
        total_price = 0
        if service == 'gravesite_maintenance' and maintenance_type:
            total_price = service_prices.get(maintenance_type, 0)
        elif service == 'schedule_anniversary':
            total_price = service_prices.get('schedule_anniversary', 0)
        elif service == 'request_a_spot' and spot_type:
            total_price = service_prices.get(spot_type, 0)

        # Handle invalid selections
        if total_price == 0:
            return render(request, 'cemetery_app/services.html', {
                'form': ServiceRequestForm(),
                'error': 'Please select a valid service and sub-option.'
            })

        # Render payment page with the calculated total price
        return render(request, 'cemetery_app/paynow.html', {
            'service': service,
            'name': name,
            'email': email,
            'total_price': total_price
        })

    return redirect('services')  # Redirect to services if not POST

# Payment success view
def payment_success(request):
    return render(request, 'cemetery_app/payment_success.html')

# Contact view
def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')

        # Check if the user already exists
        if Member.objects.filter(name=name).exists():
            messages.error(request, "This user is already registered.")
            return redirect('contact')

        # Save user in your Member model
        Member.objects.create(name=name, password=email)  # Replace with secure password handling

        # Optionally, send an email to confirm
        send_mail(
            subject="Registration Received",
            message=f"Hi {name},\n\nThank you for reaching out. You've been registered.",
            from_email="admin@example.com",
            recipient_list=[email],
        )

        messages.success(request, "User successfully registered!")
        return redirect('home')  # Redirect to home after successful registration

    return render(request, 'cemetery_app/contact.html')
def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['name']
            password = form.cleaned_data['password']

            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                return redirect('home')  # Redirect to homepage
            else:
                messages.error(request, "Invalid credentials, please try again.")
                return render(request, 'cemetery_app/login.html', {'form': form})
        else:
            messages.error(request, "Please fill in both fields.")
            return render(request, 'cemetery_app/login.html', {'form': form})
    else:
        form = LoginForm()
    return render(request, 'cemetery_app/login.html', {'form': form})


def schedule_anniversary(request):
    # Render a page to schedule anniversary details
    if request.method == 'POST':
        # Handle form submission for anniversary scheduling
        # Replace this with your actual logic
        messages.success(request, "Anniversary successfully scheduled!")
        return redirect('payment_success')

    return render(request, 'cemetery_app/services.html')
def forgot_password(request):
    return render(request, 'cemetery_app/forgot_password.html')

def password_recovery(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        
        # Simulating password recovery process (no real email is sent)
        if email:  # In a real scenario, you would check if the email exists in your database
            # Send email logic would go here (using Django's email system)
            success_message = "A password recovery link has been sent to your email."
            return render(request, 'forgot_password.html', {'success': success_message})
        else:
            error_message = "Please enter a valid email."
            return render(request, 'forgot_password.html', {'error': error_message})

    return redirect('forgot_password')