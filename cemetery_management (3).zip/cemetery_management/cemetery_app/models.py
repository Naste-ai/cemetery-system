from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

# Define the Service model
class Service(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.name

# Member model - Linking with the default User model
class Member(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True, blank=True)  # Allow null values initially
    
    def __str__(self):
        return self.user.username if self.user else 'No user'

# ContactInquiry model
class ContactInquiry(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    message = models.TextField()
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"Inquiry from {self.name}"

class ServiceRequest(models.Model):
    service = models.CharField(max_length=255)
    maintenance_type = models.CharField(max_length=255, null=True, default="default_type")  # Provide default value for nullable field
    spot_type = models.CharField(max_length=255, null=True, default="default_spot")  # Provide default value for nullable field
    name = models.CharField(max_length=100)
    email = models.EmailField()
    total_price = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)  # Default value for total_price
    created_at = models.DateTimeField(default=timezone.now)  # Default value for created_at

    def __str__(self):
        return self.name
class Deceased(models.Model):
    name = models.CharField(max_length=200)  # Full name of the deceased
    unique_id = models.CharField(max_length=100, unique=True)  # Unique identifier for tracking
    burial_section = models.CharField(max_length=100)  # Section where the deceased is buried
    date_of_death = models.DateField(null=True, blank=True)  # Optional field for date of death
    date_of_burial = models.DateField(null=True, blank=True)  # Optional field for date of burial
    notes = models.TextField(null=True, blank=True)  # Optional notes field

    def __str__(self):
        return f"{self.name} ({self.unique_id})"