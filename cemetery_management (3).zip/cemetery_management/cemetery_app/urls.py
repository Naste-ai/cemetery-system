from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('services/', views.services, name='services'),
    path('schedule-anniversary/', views.schedule_anniversary, name='schedule_anniversary'),
    path('login/', views.login_view, name='login'),
    path('paynow/', views.paynow, name='paynow'),
    path('payment_success/', views.payment_success, name='payment_success'),
    path('contact/', views.contact, name='contact'),
    path('forgot-password/', views.forgot_password, name='forgot_password'),
    path('password-recovery/', views.password_recovery, name='password_recovery'),
]

